namespace ProjetoLocadora.Models
{
    public class HomeModel
    {

        public string Titulo { get; set; }

        public string Sinopse { get; set;}

        public int Classificacao { get; set;}

    }
}