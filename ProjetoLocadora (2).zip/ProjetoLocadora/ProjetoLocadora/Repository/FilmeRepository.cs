using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProjetoLocadora.Data;
using ProjetoLocadora.Models;

namespace ProjetoLocadora.Repository
{
    public class FilmeRepository : IFilmeRepository
    {
        private readonly BancoContext _bancoContext;

        public FilmeRepository(BancoContext bancoContext)
        {
            _bancoContext = bancoContext;
        }
        public FilmeModel Adicionar(FilmeModel filme)
        {
            _bancoContext.Filmes.Add(filme);
            _bancoContext.SaveChanges();
            return filme;
        }

        public List<FilmeModel> ListarFilmes()
        {
            return _bancoContext.Filmes.ToList();
        }
    }
}